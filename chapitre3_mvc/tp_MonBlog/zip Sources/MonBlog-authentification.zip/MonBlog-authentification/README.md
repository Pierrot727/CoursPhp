# [MonBlog](http://github.com/bpesquet/MonBlog)

Support de l'article [Evoluer vers une architecture MVC en PHP] (http://bpesquet.developpez.com/tutoriels/php/evoluer-architecture-mvc/)

Auteur : [Baptiste Pesquet](https://github.com/bpesquet)


## Description

* Cette version ajoute la gestion de l'authentification des visiteurs.
* Le cours associé est disponible au [format PDF](authentification_web_php.pdf)
* Les autres versions sont disponibles sur les différentes branches du dépôt.

